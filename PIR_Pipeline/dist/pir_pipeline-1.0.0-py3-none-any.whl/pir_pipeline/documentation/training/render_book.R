setwd(
  here::here("..", "..", "documentation", "training")
)
bookdown::render_book("index.Rmd")
bookdown::clean_book()