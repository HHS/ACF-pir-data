deleteLink <- function(conn, uqid, question_id_list) {
  #' ADD ASSERTION HERE THAT THE NUMBER OF UNIQUE QUESTIONS IN newly_unlinked
  #' IS THE SAME AS THE NUMBER OF QUESTIONS IN question_id_list
  
  delete_query <- paste(
    "DELETE FROM linked",
    "WHERE uqid =", paste0("'", uqid, "'"), "AND", "question_id IN (",
      paste0("'", question_id_list, "'", collapse = ", "),
    ")"
  )
  unlinked_query <- paste(
    "SELECT year, question_id, question_name, question_text, question_number, category, section",
    "FROM linked",
    "WHERE uqid =", paste0("'", uqid, "'"), "AND", "question_id IN (",
      paste0("'", question_id_list, "'", collapse = ", "),
    ")"
  )
  newly_unlinked <- DBI::dbGetQuery(
    conn,
    unlinked_query
  )
  # Move all affected records to unlinked temporarily
  replaceInto(conn, newly_unlinked, "unlinked")
  # Delete target records
  DBI::dbExecute(conn, delete_query)
  # Remove any records in unlinked that are actually still present in the linked table
  updateUnlinked(conn)
  purrr::map(
    question_id_list,
    function(id) {
      logLink(uqid, id, "unlinked")
    }
  )
}