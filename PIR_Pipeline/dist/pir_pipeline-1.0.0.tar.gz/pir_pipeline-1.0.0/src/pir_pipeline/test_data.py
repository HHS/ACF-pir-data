import pandas as pd
import os

def create_test_data(files: list=None):
    for file in files:
        pir = pd.ExcelFile(file)
        sheets = pir.sheet_names
        id_vars = ["Unnamed: 2", "Unnamed: 3", "Unnamed: 4"]

        export_name = os.path.basename(file)
        path = os.path.join(r"C:\Users\reggie.gilliard\repos\ACF-pir-data\PIR_Pipeline\test_data", export_name)
        writer = pd.ExcelWriter(path, engine="xlsxwriter")
        for sheet in sheets:
            df = pd.read_excel(pir, sheet_name=sheet)
            if "Section" in sheet:
                varnames = df.iloc[0].to_frame().T
                if not "ids" in locals():
                    ids = df.iloc[1:, :].sample(n=10)
                df = df.merge(ids.loc[:, id_vars], on=id_vars, how="inner")
                df = pd.concat([varnames, df], axis=0)
                df["Unnamed: 3"] = df["Unnamed: 3"].map(lambda x: int(x) if x.isdigit() else x)
            df.to_excel(writer, sheet_name=sheet, index=False)

        writer._save()

if __name__ == "__main__":
    files = [
        r"C:\Users\reggie.gilliard\repos\ACF-pir-data\data\pir_export_2019.xlsx",
        r"C:\Users\reggie.gilliard\repos\ACF-pir-data\data\pir_export_2023.xlsx", 
        r"C:\Users\reggie.gilliard\repos\ACF-pir-data\data\pir_export_2022.xlsx"
    ]
    create_test_data(files)