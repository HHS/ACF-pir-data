args <- commandArgs(TRUE)
install.packages("renv", repos = "https://cloud.r-project.org/")

renv::activate()
renv::install()