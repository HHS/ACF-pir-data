def main():
    import subprocess, os
    current_dir = os.path.dirname(os.path.abspath(__file__))
    watcher_service = os.path.join(current_dir, "pir_watcher", "watcher_service.py")
    start_watcher_bat = os.path.join(current_dir, "startWatcher.bat")
    stop_watcher_bat = os.path.join(current_dir, "stopWatcher.bat")
    delete_watcher_bat = os.path.join(current_dir, "deleteWatcher.bat")
    
    if not os.path.isfile(start_watcher_bat):
        with open(start_watcher_bat, 'w') as f:
            f.write("python {} install\n".format(watcher_service))
            f.write("python {} start\n".format(watcher_service))
            
    if not os.path.isfile(stop_watcher_bat):
        with open(stop_watcher_bat, 'w') as f:
            f.write("python {} stop\n".format(watcher_service))
    
    if not os.path.isfile(delete_watcher_bat):
        with open(delete_watcher_bat, 'w') as f:
            f.write("python {} remove\n".format(watcher_service))