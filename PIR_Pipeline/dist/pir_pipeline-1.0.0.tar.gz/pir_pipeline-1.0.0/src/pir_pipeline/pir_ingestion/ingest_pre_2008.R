################################################################################
## Written by: Reggie Gilliard
## Date: 04/16/2024
## Description: Ingest data
################################################################################

# Remove objects from the R environment
rm(list = ls())

# Load packages
pkgs <- c(
  "tidyr", "dplyr", "roxygen2", "assertr", 
  "purrr", "RMariaDB", "here", "janitor",
  "furrr", "readxl", "digest", "jsonlite"
)

invisible(sapply(pkgs, library, character.only = TRUE))

path <- "C:\\Users\\reggie.gilliard\\repos\\ACF-pir-data\\data\\pir_export_2007.xlsx"
pir_2007_sheets <- readxl::excel_sheets(path)
response_list <- list()
for (sheet in pir_2007_sheets) {
  print(sheet)
  df <- readxl::read_xlsx(path, sheet = sheet)
  if (!grepl("program", tolower(sheet))) {
    try(
      response_list <- df %>%
        assertr::assert_rows(col_concat, assertr::is_uniq, GRNUM, DELNUM) %>%
        {append(response_list, list(.))}
    )
  }
}

response <- purrr::reduce(response_list, 
  function (x, y) {
    df = dplyr::full_join(x, y, by = c("GRNUM", "DELNUM"), relationship = "one-to-one")
    return(df)
  }
)

response <- response %>%
  select(-ends_with(c(".y"))) %>%
  rename_with(
    ~ gsub("\\.x", "", ., perl = TRUE), ends_with(".x")
  ) %>%
  select(-starts_with("Q"))

response <- response %>%
  mutate(across(everything(), as.character)) %>%
  pivot_longer(
    -c("GRNUM", "DELNUM"),
    names_to = "question_number",
    values_to = "answer"
  )
