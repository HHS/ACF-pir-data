# PIR Pipeline

## Installation
### Configuration
### R Package Installation
## Data Ingestion
### Ingesting from the Command Line
## Linking Questions
### Linking From the Command Line
### Creating Manual Links in the Dashboard
## Database Management
### Existing views, tables, stored procedures, and functions
### Creating views, stored procedures, and functions
## Dashboard
### Viewing the data
### Linking/Unlinking