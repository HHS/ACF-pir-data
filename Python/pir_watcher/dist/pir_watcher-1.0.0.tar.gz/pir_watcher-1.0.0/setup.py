from setuptools import setup

setup(
    data_files = [("Scripts/pir_service", ["src/watcher_service.py"])]
)